import { Event, Testimonial, TeamMember, BlogPost, Artist } from './types';

export const NAV_LINKS = [
  { name: 'Home', path: '/' },
  { name: 'Events', path: '/events' },
  { name: 'About', path: '/about' },
  { name: 'Media', path: '/media' },
  { name: 'Community', path: '/community' },
  { name: 'Contact', path: '/contact' },
];

export const UPCOMING_EVENTS: Event[] = [
  {
    id: 'vol-8',
    title: 'Dos Leches Vol. 8',
    date: 'November 24, 2025',
    time: '4:00 PM – 10:00 PM',
    venue: 'The Palace Theatre',
    description: 'Join us as we welcome an international headliner for deep Afro house grooves, sunset magic, and the community you have been searching for.',
    price: '25',
    image: 'https://picsum.photos/1080/1350',
    isUpcoming: true,
    artist: 'Francis Mercier'
  }
];

export const PAST_EVENTS: Event[] = [
  {
    id: 'vol-7',
    title: 'Dos Leches Vol. 7',
    date: 'October 12, 2025',
    time: '4:00 PM – 10:00 PM',
    venue: 'River Hall',
    description: 'Our one year anniversary celebration.',
    price: '35',
    image: 'https://picsum.photos/600/600?random=1',
    isUpcoming: false,
    artist: 'Caiiro'
  },
  {
    id: 'vol-6',
    title: 'Dos Leches Vol. 6',
    date: 'September 15, 2025',
    time: '3:00 PM – 9:00 PM',
    venue: 'Rooftop YYC',
    description: 'A golden hour special on the roof.',
    price: '30',
    image: 'https://picsum.photos/600/600?random=2',
    isUpcoming: false,
    artist: 'Local Legends'
  },
  {
    id: 'vol-5',
    title: 'Dos Leches Vol. 5',
    date: 'August 01, 2025',
    time: '5:00 PM – 11:00 PM',
    venue: 'Commonwealth',
    description: 'Summer heat and deep beats.',
    price: '25',
    image: 'https://picsum.photos/600/600?random=3',
    isUpcoming: false,
    artist: 'Shimza'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    quote: "The energy is unlike anything else in Calgary. It feels like a family reunion where everyone loves good music.",
    name: "Sarah Jenkins",
    role: "Regular Attendee"
  },
  {
    id: 2,
    quote: "Finally, a day party that focuses on the music and the vibe, not just bottle service. 10/10.",
    name: "Marcus T.",
  },
  {
    id: 3,
    quote: "Golden hour at Vol. 6 changed my life. The transition from day to night was spiritual.",
    name: "Elena Rodriguez",
  }
];

export const TEAM: TeamMember[] = [
  {
    id: 1,
    name: "Mateo Rivera",
    role: "Founder & Creative Director",
    bio: "A lifelong crate digger with a passion for bringing people together through rhythm. Mateo founded Dos Leches to fill the void of Afro house in YYC.",
    image: "https://picsum.photos/300/300?random=10"
  },
  {
    id: 2,
    name: "Chloe Dubois",
    role: "Community Manager",
    bio: "Ensuring every person who walks through our doors feels like they belong. Chloe manages our vibe patrol and guest experience.",
    image: "https://picsum.photos/300/300?random=11"
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 1,
    title: "What is Afro House? A Genre Guide",
    category: "GENRE GUIDE",
    excerpt: "Explore the roots, the rhythms, and the evolution of the sound that drives our Sundays.",
    author: "Mateo Rivera",
    date: "Oct 20, 2025",
    image: "https://picsum.photos/1200/800?random=20"
  },
  {
    id: 2,
    title: "Vol. 7 Recap: Our First Year Anniversary",
    category: "EVENT RECAP",
    excerpt: "Relive the magic of our biggest event yet. Photos, track IDs, and memories.",
    author: "Chloe Dubois",
    date: "Oct 15, 2025",
    image: "https://picsum.photos/1200/800?random=21"
  }
];

export const ARTISTS: Artist[] = [
  {
    id: 1,
    name: "Caiiro",
    origin: "South Africa",
    genre: "Afro House",
    image: "https://picsum.photos/600/600?random=30"
  },
  {
    id: 2,
    name: "Francis Mercier",
    origin: "USA / Haiti",
    genre: "Deep House",
    image: "https://picsum.photos/600/600?random=31"
  },
  {
    id: 3,
    name: "Nitefreak",
    origin: "Zimbabwe",
    genre: "Afro Tech",
    image: "https://picsum.photos/600/600?random=32"
  },
  {
    id: 4,
    name: "Local Resident",
    origin: "Calgary, AB",
    genre: "Melodic House",
    image: "https://picsum.photos/600/600?random=33"
  }
];