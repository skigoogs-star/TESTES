import React from 'react';
import { Reveal } from '../components/ui/Reveal';
import { PageTransition } from '../components/ui/PageTransition';
import { NewsletterSection } from '../components/NewsletterSection';
import { TEAM } from '../constants';
import { Sun, Music, Heart, Users } from 'lucide-react';

export const About = () => {
  return (
    <PageTransition>
      <div className="pt-20 bg-white">
         {/* Hero */}
         <div className="relative h-[50vh] min-h-[400px]">
          <div className="absolute inset-0 bg-sunset-amber/20" />
          <img src="https://picsum.photos/1920/800?blur=2" alt="Crowd" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
               <h1 className="text-white font-heading font-bold text-5xl md:text-6xl text-center">This Is Dos Leches</h1>
          </div>
        </div>

        {/* Story */}
        <section className="py-20 container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center mb-16">
              <Reveal>
                  <h2 className="text-sunset-amber font-bold tracking-widest uppercase mb-4">Our Story</h2>
                  <h3 className="font-heading font-bold text-3xl md:text-4xl text-charcoal mb-8">How It Started</h3>
                  <div className="text-lg text-gray-600 space-y-6 text-left leading-relaxed">
                      <p>
                          Dos Leches started with a simple question: What if Calgary had a space where Afro house, golden hour, and community collided? In early 2024, we threw our first event—Vol. 0. We invited 50 friends to a small patio. By sunset, we knew this was bigger than us.
                      </p>
                      <p>
                          One year and eight events later, Dos Leches is Calgary's home for Afro house, melodic journeys, and the people who show up for both. We've welcomed thousands to the dance floor, supported emerging and international artists, and built a community that feels like family.
                      </p>
                      <p>
                           Every "Vol." is a ritual. We gather at golden hour because endings are beginnings. We play Afro house because it's a feeling that transcends borders.
                      </p>
                  </div>
              </Reveal>
          </div>
        </section>

        {/* Values */}
        <section className="py-20 bg-warm-white">
          <div className="container mx-auto px-6">
              <Reveal>
                  <h2 className="font-heading font-bold text-3xl text-center text-charcoal mb-12">Our Values</h2>
              </Reveal>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {[
                      { icon: Sun, title: "Sunset as Sacred", desc: "Golden hour isn't just lighting—it's a mindset. We design every event around the transition from day to night." },
                      { icon: Music, title: "Afro House Rooted", desc: "We celebrate the African diaspora and Latin roots that created this sound with pride and respect." },
                      { icon: Heart, title: "Community First", desc: "Growth happens when people bring friends because they genuinely want them to feel what they felt." },
                      { icon: Users, title: "Accessible & Inclusive", desc: "From pricing to vibe, we remove barriers. Everyone belongs on our floor." }
                  ].map((item, idx) => (
                      <Reveal key={idx} delay={idx * 0.1}>
                          <div className="bg-white p-8 rounded-xl shadow-sm text-center h-full hover:-translate-y-2 transition-transform duration-300">
                              <div className="w-16 h-16 mx-auto bg-warm-sand rounded-full flex items-center justify-center text-deep-terracotta mb-6">
                                  <item.icon size={32} />
                              </div>
                              <h4 className="font-heading font-bold text-xl mb-3 text-charcoal">{item.title}</h4>
                              <p className="text-gray-600 text-sm">{item.desc}</p>
                          </div>
                      </Reveal>
                  ))}
              </div>
          </div>
        </section>

        {/* Team */}
        <section className="py-20 container mx-auto px-6">
          <Reveal>
              <h2 className="font-heading font-bold text-3xl text-center text-charcoal mb-16">The Humans Behind the Sunsets</h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
              {TEAM.map((member) => (
                  <Reveal key={member.id}>
                      <div className="flex flex-col items-center text-center">
                          <div className="w-48 h-48 rounded-full overflow-hidden mb-6 shadow-lg border-4 border-white">
                              <img src={member.image} alt={member.name} className="w-full h-full object-cover" />
                          </div>
                          <h3 className="font-heading font-bold text-2xl text-charcoal">{member.name}</h3>
                          <p className="text-sunset-amber font-bold text-sm uppercase mb-4">{member.role}</p>
                          <p className="text-gray-600 text-sm max-w-sm">{member.bio}</p>
                      </div>
                  </Reveal>
              ))}
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 bg-charcoal text-white text-center">
          <div className="container mx-auto px-6">
              <Reveal>
                  <h2 className="font-heading font-bold text-3xl mb-4">Press & Partnerships</h2>
                  <p className="max-w-xl mx-auto mb-8 opacity-90">Interested in covering our story, partnering with us, or booking Dos Leches for your venue?</p>
                  <a href="mailto:press@dosleches.ca" className="inline-block bg-white text-deep-terracotta font-bold px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors">Contact Us</a>
              </Reveal>
          </div>
        </section>
        
        <NewsletterSection />
      </div>
    </PageTransition>
  );
};