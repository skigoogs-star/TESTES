import React from 'react';
import { Reveal } from '../components/ui/Reveal';
import { Button } from '../components/ui/Button';
import { PageTransition } from '../components/ui/PageTransition';
import { Mail, MapPin, Instagram } from 'lucide-react';

export const Contact = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thanks for reaching out! We'll get back to you shortly.");
  };

  return (
    <PageTransition>
      <div className="pt-20 bg-warm-white min-h-screen">
        <div className="bg-warm-sand py-16 text-center px-6">
          <h1 className="font-heading font-bold text-4xl text-charcoal mb-2">Let's Connect</h1>
          <p className="text-gray-600">Questions, partnerships, press, or just want to say hi?</p>
        </div>

        <div className="container mx-auto px-6 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              {/* Form */}
              <Reveal>
                  <div className="bg-white p-8 rounded-2xl shadow-lg">
                      <h2 className="font-heading font-bold text-2xl text-charcoal mb-6">Send a Message</h2>
                      <form onSubmit={handleSubmit} className="space-y-6">
                          <div>
                              <label className="block text-sm font-bold text-charcoal mb-2">Your Name *</label>
                              <input required type="text" className="w-full border-2 border-warm-sand rounded-lg px-4 py-3 focus:outline-none focus:border-vibrant-teal focus:ring-1 focus:ring-vibrant-teal transition-colors" />
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-charcoal mb-2">Email Address *</label>
                              <input required type="email" className="w-full border-2 border-warm-sand rounded-lg px-4 py-3 focus:outline-none focus:border-vibrant-teal focus:ring-1 focus:ring-vibrant-teal transition-colors" />
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-charcoal mb-2">Reason *</label>
                              <select className="w-full border-2 border-warm-sand rounded-lg px-4 py-3 focus:outline-none focus:border-vibrant-teal transition-colors bg-white">
                                  <option>General Inquiry</option>
                                  <option>Press / Media</option>
                                  <option>Partnership</option>
                                  <option>Artist Booking</option>
                              </select>
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-charcoal mb-2">Message *</label>
                              <textarea required rows={5} className="w-full border-2 border-warm-sand rounded-lg px-4 py-3 focus:outline-none focus:border-vibrant-teal focus:ring-1 focus:ring-vibrant-teal transition-colors"></textarea>
                          </div>
                          <Button type="submit" variant="primary" className="w-full">Send Message →</Button>
                          <p className="text-xs text-gray-500 text-center">We'll get back to you within 2 business days.</p>
                      </form>
                  </div>
              </Reveal>

              {/* Info */}
              <div className="space-y-8 flex flex-col justify-center">
                  <Reveal delay={0.2}>
                      <div className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-sm">
                          <div className="bg-sunset-amber/10 p-3 rounded-full text-sunset-amber">
                              <Mail size={24} />
                          </div>
                          <div>
                              <h3 className="font-heading font-bold text-xl text-charcoal mb-2">Email Us</h3>
                              <p className="text-gray-600 text-sm">General: info@dosleches.ca</p>
                              <p className="text-gray-600 text-sm">Press: press@dosleches.ca</p>
                          </div>
                      </div>
                  </Reveal>

                  <Reveal delay={0.3}>
                      <div className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-sm">
                          <div className="bg-sunset-amber/10 p-3 rounded-full text-sunset-amber">
                              <Instagram size={24} />
                          </div>
                          <div>
                              <h3 className="font-heading font-bold text-xl text-charcoal mb-2">Social Media</h3>
                              <p className="text-gray-600 text-sm mb-2">Instagram: @dos.leche5</p>
                              <p className="text-gray-600 text-sm">We respond within 24 hours on DM.</p>
                          </div>
                      </div>
                  </Reveal>

                  <Reveal delay={0.4}>
                      <div className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-sm">
                          <div className="bg-sunset-amber/10 p-3 rounded-full text-sunset-amber">
                              <MapPin size={24} />
                          </div>
                          <div>
                              <h3 className="font-heading font-bold text-xl text-charcoal mb-2">Location</h3>
                              <p className="text-gray-600 text-sm">Based in Calgary, AB</p>
                              <p className="text-gray-600 text-sm">Events across various YYC venues</p>
                          </div>
                      </div>
                  </Reveal>
              </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};