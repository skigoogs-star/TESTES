import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, MapPin, ArrowRight, Play, ArrowUpRight, Clock } from 'lucide-react';
import { Reveal } from '../components/ui/Reveal';
import { Button } from '../components/ui/Button';
import { PageTransition } from '../components/ui/PageTransition';
import { NewsletterSection } from '../components/NewsletterSection';
import { Marquee } from '../components/ui/Marquee';
import { UPCOMING_EVENTS, PAST_EVENTS, TESTIMONIALS } from '../constants';
import { motion } from 'framer-motion';

export const Home = () => {
  const nextEvent = UPCOMING_EVENTS[0];

  return (
    <PageTransition>
      <div className="bg-warm-white">
        
        {/* Hero Section - Editorial Style */}
        <div className="relative min-h-screen w-full overflow-hidden flex flex-col justify-center pt-20 pb-12">
          <div className="container mx-auto px-4 relative z-10">
            
            {/* Top Text */}
            <motion.h1 
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="font-heading font-black text-[12vw] leading-[0.85] tracking-tighter text-charcoal mix-blend-overlay"
            >
              DOS
            </motion.h1>

            {/* Middle Image & Text Split */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-8 my-[-2vw]">
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
                className="w-full md:w-1/2 aspect-video md:aspect-[16/9] relative rounded-2xl overflow-hidden shadow-2xl rotate-1 hover:rotate-0 transition-transform duration-700"
              >
                <video 
                  autoPlay 
                  muted 
                  loop 
                  playsInline 
                  className="absolute inset-0 w-full h-full object-cover"
                  poster="https://picsum.photos/1920/1080"
                >
                   {/* Placeholder video source - in real app this would be local asset */}
                   <source src="https://assets.mixkit.co/videos/preview/mixkit-people-dancing-at-a-party-4275-large.mp4" type="video/mp4" />
                </video>
                <div className="absolute inset-0 bg-sunset-amber/20 mix-blend-screen" />
                
                {/* Floating Sticker */}
                <div className="absolute top-4 right-4 bg-white rounded-full w-24 h-24 flex items-center justify-center animate-spin-slow shadow-lg">
                    <div className="text-[10px] font-bold uppercase tracking-widest text-center">
                      Calgary<br/>Afro House<br/>Ritual
                    </div>
                </div>
              </motion.div>

              <div className="w-full md:w-1/2 flex flex-col items-end text-right">
                 <motion.h1 
                    initial={{ y: 100, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
                    className="font-heading font-black text-[12vw] leading-[0.85] tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-sunset-amber to-coral"
                  >
                    LECHES
                  </motion.h1>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 }}
                    className="mt-8 max-w-md"
                  >
                    <p className="text-xl md:text-2xl font-medium text-charcoal mb-6">
                      Where golden hour meets underground energy.
                    </p>
                    <div className="flex justify-end gap-4">
                      <Button variant="primary" className="rounded-full">Get Tickets</Button>
                      <Button variant="outline" className="rounded-full border-charcoal text-charcoal hover:bg-charcoal hover:text-white">
                        <Play size={16} className="mr-2" /> Story
                      </Button>
                    </div>
                  </motion.div>
              </div>
            </div>
          </div>
        </div>

        {/* Marquee Strip */}
        <div className="bg-charcoal py-6 rotate-[-1deg] scale-105 border-y-4 border-sunset-amber">
          <Marquee>
            <span className="font-heading font-black text-4xl md:text-6xl text-warm-white mx-8 uppercase tracking-tighter">
              Sunset Ritual • Afro House • Community First • Golden Hour Magic •
            </span>
          </Marquee>
        </div>

        {/* Next Event - Ticket Style */}
        <section className="py-24 container mx-auto px-6">
          <Reveal>
            <div className="flex items-end justify-between mb-12 border-b border-charcoal pb-4">
               <h2 className="font-heading font-black text-5xl md:text-7xl uppercase text-charcoal">Next Up</h2>
               <div className="hidden md:block text-right">
                  <p className="font-bold text-sunset-amber uppercase tracking-widest">Vol. 08</p>
                  <p className="text-gray-500">The Palace Theatre</p>
               </div>
            </div>
          </Reveal>

          <Reveal>
            <div className="group relative bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col lg:flex-row min-h-[600px] border-2 border-charcoal">
                {/* Image Side */}
                <div className="lg:w-1/2 relative overflow-hidden">
                    <div className="absolute inset-0 bg-charcoal/20 group-hover:bg-transparent transition-colors z-10 duration-500" />
                    <img 
                      src={nextEvent.image} 
                      alt={nextEvent.title} 
                      className="w-full h-full object-cover scale-105 group-hover:scale-100 transition-transform duration-1000 ease-in-out grayscale group-hover:grayscale-0" 
                    />
                    <div className="absolute bottom-0 left-0 p-8 z-20">
                        <h3 className="font-heading font-black text-6xl text-white leading-none mb-2">{nextEvent.artist}</h3>
                        <span className="inline-block bg-sunset-amber text-white font-bold px-4 py-1 rounded-full uppercase text-sm">Headliner</span>
                    </div>
                </div>

                {/* Details Side */}
                <div className="lg:w-1/2 p-8 md:p-12 flex flex-col justify-between bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
                    <div>
                        <div className="flex justify-between items-start mb-8">
                            <div>
                              <h2 className="font-heading font-bold text-4xl text-charcoal mb-2">{nextEvent.title}</h2>
                              <p className="text-gray-600 max-w-md">{nextEvent.description}</p>
                            </div>
                            <div className="w-20 h-20 rounded-full bg-black text-white flex items-center justify-center font-heading font-bold text-xl rotate-12 shadow-lg group-hover:rotate-0 transition-all duration-500">
                                ${nextEvent.price}
                            </div>
                        </div>

                        <div className="space-y-6 border-t border-dashed border-charcoal/30 pt-8">
                            <div className="flex items-center gap-6 group/item">
                                <div className="w-12 h-12 rounded-full bg-warm-sand flex items-center justify-center text-charcoal group-hover/item:bg-sunset-amber group-hover/item:text-white transition-colors">
                                  <Calendar size={20} />
                                </div>
                                <div>
                                  <p className="text-xs uppercase tracking-widest text-gray-500">Date</p>
                                  <p className="font-heading font-bold text-xl text-charcoal">{nextEvent.date}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-6 group/item">
                                <div className="w-12 h-12 rounded-full bg-warm-sand flex items-center justify-center text-charcoal group-hover/item:bg-sunset-amber group-hover/item:text-white transition-colors">
                                  <Clock size={20} />
                                </div>
                                <div>
                                  <p className="text-xs uppercase tracking-widest text-gray-500">Time</p>
                                  <p className="font-heading font-bold text-xl text-charcoal">{nextEvent.time}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-6 group/item">
                                <div className="w-12 h-12 rounded-full bg-warm-sand flex items-center justify-center text-charcoal group-hover/item:bg-sunset-amber group-hover/item:text-white transition-colors">
                                  <MapPin size={20} />
                                </div>
                                <div>
                                  <p className="text-xs uppercase tracking-widest text-gray-500">Location</p>
                                  <p className="font-heading font-bold text-xl text-charcoal">{nextEvent.venue}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="mt-12">
                        <Button variant="primary" className="w-full py-6 text-xl rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all">
                          Secure Your Spot
                        </Button>
                    </div>
                </div>
            </div>
          </Reveal>
        </section>

        {/* Bento Grid Section */}
        <section className="py-20 container mx-auto px-6">
          <Reveal>
             <h2 className="font-heading font-black text-5xl md:text-6xl text-center mb-16">THE <span className="text-sunset-amber">EXPERIENCE</span></h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-4 grid-rows-3 md:grid-rows-2 gap-4 h-auto md:h-[800px]">
              
              {/* Item 1: Large Video/Image */}
              <div className="md:col-span-2 md:row-span-2 relative rounded-3xl overflow-hidden group">
                 <img src="https://picsum.photos/800/800?random=10" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="Vibe" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-8">
                    <h3 className="text-white font-heading font-bold text-3xl">Sunset Rituals</h3>
                    <p className="text-gray-300 mt-2">We gather at golden hour because endings are beginnings.</p>
                 </div>
              </div>

              {/* Item 2: Solid Color Info */}
              <div className="md:col-span-1 bg-coral rounded-3xl p-8 flex flex-col justify-between text-charcoal hover:bg-sunset-amber transition-colors duration-300">
                  <ArrowUpRight size={40} className="self-end" />
                  <div>
                    <h3 className="font-heading font-black text-4xl mb-2">8</h3>
                    <p className="font-bold uppercase tracking-wider">Sold Out Events</p>
                  </div>
              </div>

              {/* Item 3: Image */}
              <div className="md:col-span-1 relative rounded-3xl overflow-hidden group">
                 <img src="https://picsum.photos/400/400?random=11" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" alt="Crowd" />
              </div>

              {/* Item 4: Text Box */}
              <div className="md:col-span-2 bg-charcoal text-white rounded-3xl p-8 md:p-12 flex flex-col justify-center relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-sunset-amber rounded-full blur-3xl opacity-50" />
                  <h3 className="font-heading font-bold text-2xl md:text-3xl mb-4 relative z-10">Not Just A Party.</h3>
                  <p className="text-gray-400 text-lg relative z-10">
                    Dos Leches is Calgary's home for Afro house. We play music because it's a feeling, not a genre. 
                    Whether you're here for the beats or the people, you belong.
                  </p>
                  <Link to="/about" className="inline-flex items-center gap-2 text-sunset-amber font-bold mt-6 hover:gap-4 transition-all">
                    Read Our Story <ArrowRight size={20} />
                  </Link>
              </div>

          </div>
        </section>

        {/* Horizontal Scroll Gallery */}
        <section className="py-20 bg-charcoal text-white overflow-hidden">
           <div className="container mx-auto px-6 mb-12 flex justify-between items-end">
              <div>
                <h2 className="font-heading font-black text-4xl md:text-6xl">PAST <span className="stroke-text text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500">ARCHIVES</span></h2>
              </div>
              <Link to="/media" className="hidden md:block border-b border-white pb-1 hover:text-sunset-amber hover:border-sunset-amber transition-colors">View All Galleries</Link>
           </div>

           <div className="flex overflow-x-auto gap-8 px-6 pb-12 hide-scrollbar snap-x">
              {PAST_EVENTS.map((event, i) => (
                 <motion.div 
                    key={event.id}
                    whileHover={{ y: -10 }}
                    className="min-w-[320px] md:min-w-[450px] aspect-[3/4] relative rounded-2xl overflow-hidden snap-center bg-gray-800 group cursor-pointer"
                  >
                    <img src={event.image} alt={event.title} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
                    
                    <div className="absolute top-6 left-6 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
                      <span className="text-xs font-bold uppercase tracking-widest">Vol. {7 - i}</span>
                    </div>

                    <div className="absolute bottom-0 left-0 p-8 w-full transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                       <p className="text-sunset-amber text-sm font-bold mb-1">{event.date}</p>
                       <h3 className="font-heading font-black text-3xl leading-none mb-2">{event.venue}</h3>
                    </div>
                 </motion.div>
              ))}
           </div>
        </section>
        
        <NewsletterSection />
      </div>
    </PageTransition>
  );
};