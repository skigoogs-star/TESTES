import React from 'react';
import { Reveal } from '../components/ui/Reveal';
import { PageTransition } from '../components/ui/PageTransition';
import { PlayCircle } from 'lucide-react';

export const Media = () => {
  return (
    <PageTransition>
      <div className="pt-20 bg-warm-white min-h-screen">
          <div className="bg-charcoal py-12 text-center">
              <h1 className="font-heading font-bold text-4xl text-white mb-2">See the Sunsets. Feel the Energy.</h1>
              <p className="text-gray-400">Every moment, captured.</p>
          </div>

          {/* Photo Gallery Grid */}
          <section className="container mx-auto px-6 py-16">
              <Reveal>
                  <h2 className="font-heading font-bold text-2xl text-charcoal mb-8">Photo Gallery</h2>
              </Reveal>
              <div className="columns-1 md:columns-3 gap-4 space-y-4">
                  {Array.from({ length: 9 }).map((_, i) => (
                      <Reveal key={i} delay={i * 0.05}>
                          <div className="break-inside-avoid rounded-xl overflow-hidden relative group cursor-pointer">
                              <img 
                                  src={`https://picsum.photos/600/${i % 2 === 0 ? 800 : 600}?random=${i + 50}`} 
                                  alt="Gallery" 
                                  className="w-full h-auto transition-transform duration-500 group-hover:scale-105" 
                              />
                              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                  <span className="text-white font-bold border-b border-white pb-1">View Full</span>
                              </div>
                          </div>
                      </Reveal>
                  ))}
              </div>
              <div className="text-center mt-12">
                  <button className="text-charcoal underline hover:text-sunset-amber font-bold transition-colors">Load More Photos</button>
              </div>
          </section>

          {/* Videos */}
          <section className="bg-white py-16">
              <div className="container mx-auto px-6">
                  <Reveal>
                      <h2 className="font-heading font-bold text-2xl text-charcoal mb-8">Video Highlights</h2>
                  </Reveal>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="aspect-video bg-gray-900 rounded-xl relative group cursor-pointer overflow-hidden">
                           <img src="https://picsum.photos/1200/675?random=80" alt="Video Thumbnail" className="w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700" />
                           <div className="absolute inset-0 flex items-center justify-center">
                              <PlayCircle size={64} className="text-white opacity-90 group-hover:scale-110 transition-transform" />
                           </div>
                           <div className="absolute bottom-4 left-4 text-white font-heading font-bold">Vol. 7 Aftermovie</div>
                      </div>
                      <div className="aspect-video bg-gray-900 rounded-xl relative group cursor-pointer overflow-hidden">
                           <img src="https://picsum.photos/1200/675?random=81" alt="Video Thumbnail" className="w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700" />
                           <div className="absolute inset-0 flex items-center justify-center">
                              <PlayCircle size={64} className="text-white opacity-90 group-hover:scale-110 transition-transform" />
                           </div>
                           <div className="absolute bottom-4 left-4 text-white font-heading font-bold">Golden Hour Highlights</div>
                      </div>
                  </div>
              </div>
          </section>

          {/* Mixes */}
          <section className="py-16 bg-gradient-to-r from-sunset-amber to-coral text-white">
              <div className="container mx-auto px-6">
                   <Reveal>
                      <h2 className="font-heading font-bold text-2xl mb-8">Listen to the Vibes</h2>
                  </Reveal>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {[1, 2, 3].map((item) => (
                          <div key={item} className="bg-black/20 p-4 rounded-xl backdrop-blur-sm">
                              <div className="h-32 bg-gray-800 rounded flex items-center justify-center mb-4 text-gray-500 text-xs">
                                  SoundCloud Embed Placeholder
                              </div>
                              <h3 className="font-bold text-lg">Vol. {7 - item + 1} Live Set</h3>
                              <p className="text-xs opacity-70">Recorded Live at The Palace</p>
                          </div>
                      ))}
                  </div>
              </div>
          </section>
      </div>
    </PageTransition>
  );
};