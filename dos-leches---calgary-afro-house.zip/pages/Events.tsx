import React, { useState, useMemo } from 'react';
import { Calendar, MapPin, Clock, ArrowUpRight } from 'lucide-react';
import { Reveal } from '../components/ui/Reveal';
import { Button } from '../components/ui/Button';
import { PageTransition } from '../components/ui/PageTransition';
import { NewsletterSection } from '../components/NewsletterSection';
import { UPCOMING_EVENTS, PAST_EVENTS } from '../constants';

export const Events = () => {
  const [filter, setFilter] = useState<'all' | '2024' | '2025'>('all');

  const filteredPastEvents = useMemo(() => {
    if (filter === 'all') return PAST_EVENTS;
    return PAST_EVENTS.filter(event => event.date.includes(filter));
  }, [filter]);

  return (
    <PageTransition>
      <div className="pt-32 bg-warm-white min-h-screen">
        
        <div className="container mx-auto px-6">
           <div className="flex flex-col md:flex-row justify-between items-end mb-20 border-b-2 border-charcoal pb-6">
              <Reveal>
                <h1 className="font-heading font-black text-6xl md:text-8xl text-charcoal uppercase tracking-tighter">
                  The <span className="text-transparent bg-clip-text bg-gradient-to-r from-sunset-amber to-coral">Lineup</span>
                </h1>
              </Reveal>
              <Reveal delay={0.2}>
                <p className="text-xl text-gray-600 max-w-md text-right pb-2">
                  Every event is a journey. Every sunset is a new beginning.
                </p>
              </Reveal>
           </div>

          {/* Upcoming */}
          <div className="mb-32">
              <div className="flex items-center gap-4 mb-12">
                 <div className="h-px bg-charcoal flex-grow"></div>
                 <h2 className="font-heading font-bold text-xl uppercase tracking-widest text-charcoal">Upcoming</h2>
                 <div className="h-px bg-charcoal flex-grow"></div>
              </div>

              {UPCOMING_EVENTS.map((event) => (
                  <Reveal key={event.id}>
                      <div className="group relative bg-charcoal text-white rounded-[2rem] overflow-hidden shadow-2xl hover:shadow-sunset-amber/20 transition-all duration-500">
                          <div className="absolute inset-0">
                             <img src={event.image} alt="bg" className="w-full h-full object-cover opacity-30 group-hover:opacity-20 transition-opacity" />
                          </div>
                          
                          <div className="relative z-10 p-8 md:p-16 flex flex-col md:flex-row gap-12 items-center">
                              {/* Date Circle */}
                              <div className="flex-shrink-0 w-32 h-32 rounded-full border-2 border-sunset-amber flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm">
                                 <span className="text-sunset-amber font-bold uppercase text-sm tracking-widest">Nov</span>
                                 <span className="font-heading font-black text-5xl">24</span>
                              </div>

                              <div className="flex-grow text-center md:text-left">
                                 <div className="inline-block bg-sunset-amber px-3 py-1 rounded text-xs font-bold uppercase mb-4">Selling Fast</div>
                                 <h3 className="font-heading font-black text-5xl md:text-6xl mb-2">{event.title}</h3>
                                 <p className="text-2xl text-gray-300 font-light mb-6">w/ {event.artist}</p>
                                 
                                 <div className="flex flex-wrap justify-center md:justify-start gap-6 text-sm text-gray-400 font-medium uppercase tracking-wider">
                                     <span className="flex items-center gap-2"><Clock size={16} className="text-sunset-amber"/> {event.time}</span>
                                     <span className="flex items-center gap-2"><MapPin size={16} className="text-sunset-amber"/> {event.venue}</span>
                                 </div>
                              </div>

                              <div className="flex-shrink-0">
                                  <Button variant="primary" className="rounded-full px-10 py-4 text-lg bg-white text-charcoal hover:bg-sunset-amber hover:text-white border-0 shadow-none">
                                     Get Tickets <ArrowUpRight className="ml-2" />
                                  </Button>
                              </div>
                          </div>
                      </div>
                  </Reveal>
              ))}
          </div>

          {/* Archive */}
          <div>
              <div className="flex flex-col md:flex-row justify-between items-center mb-12">
                  <h2 className="font-heading font-black text-4xl md:text-5xl text-charcoal uppercase">Archive</h2>
                  <div className="flex gap-2 mt-4 md:mt-0 bg-white p-1 rounded-full shadow-sm border border-gray-100">
                      {(['all', '2025', '2024'] as const).map((year) => (
                          <button
                              key={year}
                              onClick={() => setFilter(year)}
                              className={`px-6 py-2 rounded-full text-sm font-bold transition-all duration-300 uppercase ${
                                  filter === year ? 'bg-charcoal text-white shadow-md' : 'text-gray-500 hover:bg-gray-100'
                              }`}
                          >
                              {year === 'all' ? 'All' : year}
                          </button>
                      ))}
                  </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                  {filteredPastEvents.length > 0 ? (
                    filteredPastEvents.map((event, idx) => (
                        <Reveal key={event.id} delay={idx * 0.1}>
                            <div className="group relative bg-white border border-gray-200 hover:border-charcoal p-6 rounded-2xl transition-all duration-300 hover:shadow-lg flex flex-col md:flex-row items-center gap-6">
                                <div className="w-full md:w-48 h-32 rounded-xl overflow-hidden">
                                   <img src={event.image} alt={event.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" />
                                </div>
                                
                                <div className="flex-grow flex flex-col md:flex-row md:items-center justify-between gap-4 w-full">
                                   <div>
                                      <p className="text-sunset-amber text-xs font-bold uppercase tracking-widest mb-1">Vol. {7 - idx}</p>
                                      <h3 className="font-heading font-bold text-2xl text-charcoal">{event.title}</h3>
                                      <p className="text-gray-500 text-sm">{event.artist}</p>
                                   </div>
                                   
                                   <div className="text-right md:text-right">
                                      <p className="font-bold text-charcoal">{event.date}</p>
                                      <p className="text-gray-400 text-sm">{event.venue}</p>
                                   </div>
                                </div>
                                
                                <div className="w-12 h-12 rounded-full border border-gray-200 flex items-center justify-center group-hover:bg-charcoal group-hover:text-white transition-colors">
                                    <ArrowUpRight size={20} />
                                </div>
                            </div>
                        </Reveal>
                    ))
                  ) : (
                    <div className="py-20 text-center text-gray-400 border-2 border-dashed border-gray-200 rounded-2xl">
                        No events found for this period.
                    </div>
                  )}
              </div>
          </div>
        </div>
        <div className="mt-20">
            <NewsletterSection />
        </div>
      </div>
    </PageTransition>
  );
};