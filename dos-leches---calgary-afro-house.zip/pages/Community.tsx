import React from 'react';
import { Reveal } from '../components/ui/Reveal';
import { PageTransition } from '../components/ui/PageTransition';
import { BLOG_POSTS, ARTISTS } from '../constants';
import { Button } from '../components/ui/Button';

export const Community = () => {
  return (
    <PageTransition>
      <div className="pt-20 bg-white">
        {/* Hero */}
         <div className="bg-warm-sand py-20 text-center px-6">
              <Reveal>
                  <h1 className="font-heading font-bold text-4xl md:text-5xl text-charcoal mb-4">You Are the Vibe</h1>
                  <p className="text-xl text-gray-700 max-w-2xl mx-auto">This is your community. These are your stories.</p>
              </Reveal>
         </div>

         {/* Blog */}
         <section className="py-16 container mx-auto px-6">
              <Reveal>
                  <h2 className="font-heading font-bold text-3xl text-charcoal mb-2">Stories from the Sunset</h2>
                  <p className="text-gray-600 mb-10">Genre guides, event recaps, and artist interviews.</p>
              </Reveal>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  {BLOG_POSTS.map((post) => (
                      <Reveal key={post.id}>
                          <div className="flex flex-col h-full group cursor-pointer">
                              <div className="rounded-xl overflow-hidden h-64 mb-6">
                                  <img src={post.image} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                              </div>
                              <span className="text-sunset-amber text-xs font-bold uppercase tracking-widest mb-2">{post.category}</span>
                              <h3 className="font-heading font-bold text-2xl text-charcoal mb-3 group-hover:text-sunset-amber transition-colors">{post.title}</h3>
                              <p className="text-gray-600 mb-4 flex-grow">{post.excerpt}</p>
                              <div className="text-sm text-gray-400 flex justify-between items-center border-t pt-4 mt-auto">
                                  <span>{post.author}</span>
                                  <span>{post.date}</span>
                              </div>
                          </div>
                      </Reveal>
                  ))}
              </div>
         </section>

         {/* Artists */}
         <section className="py-20 bg-charcoal text-white">
              <div className="container mx-auto px-6">
                  <Reveal>
                      <h2 className="font-heading font-bold text-3xl text-center mb-4">Meet the Artists</h2>
                      <p className="text-center text-gray-400 mb-12 max-w-2xl mx-auto">The DJs and producers who bring the sound to life.</p>
                  </Reveal>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                      {ARTISTS.map((artist, idx) => (
                           <Reveal key={artist.id} delay={idx * 0.1}>
                              <div className="bg-white/5 p-6 rounded-xl border border-white/10 hover:bg-white/10 transition-colors">
                                  <div className="w-full aspect-square rounded-lg overflow-hidden mb-4">
                                      <img src={artist.image} alt={artist.name} className="w-full h-full object-cover" />
                                  </div>
                                  <h3 className="font-heading font-bold text-xl">{artist.name}</h3>
                                  <p className="text-sunset-amber text-sm mb-2">{artist.genre}</p>
                                  <p className="text-gray-400 text-xs">{artist.origin}</p>
                              </div>
                           </Reveal>
                      ))}
                  </div>
              </div>
         </section>

         {/* UGC */}
         <section className="py-20 container mx-auto px-6 text-center">
              <h2 className="font-heading font-bold text-3xl text-charcoal mb-8">Faces of the Tribe</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  {Array.from({length: 4}).map((_, i) => (
                      <img key={i} src={`https://picsum.photos/400/400?random=${i+100}`} className="rounded-lg w-full h-full object-cover hover:opacity-80 transition-opacity" alt="UGC" />
                  ))}
              </div>
              <Button variant="outline" className="text-vibrant-teal border-vibrant-teal hover:bg-vibrant-teal hover:text-white">Tag Us on Instagram →</Button>
         </section>
      </div>
    </PageTransition>
  );
};