import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Music, Video, ArrowUpRight } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-charcoal text-white pt-24 pb-12 rounded-t-[3rem] mt-[-2rem] relative z-10">
      <div className="container mx-auto px-6">
        
        {/* Big Title */}
        <div className="border-b border-white/10 pb-12 mb-12 flex flex-col md:flex-row justify-between items-start md:items-end">
           <h2 className="font-heading font-black text-[15vw] leading-[0.8] text-transparent bg-clip-text bg-gradient-to-b from-white/20 to-transparent select-none pointer-events-none">
             DOS
           </h2>
           <div className="text-right mt-8 md:mt-0">
              <p className="text-sunset-amber font-bold uppercase tracking-widest mb-2">Est. 2024</p>
              <p className="text-xl font-bold">Calgary, Alberta</p>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          
          {/* Brand */}
          <div className="space-y-6">
            <p className="text-gray-400 text-lg leading-relaxed max-w-xs">
              Calgary's home for Afro house. Where music moves you, the sunset stops you, and the people around you feel like family.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-sunset-amber transition-colors"><Instagram size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-sunset-amber transition-colors"><Music size={18} /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-sunset-amber transition-colors"><Video size={18} /></a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-heading font-bold text-lg mb-6 text-white">Sitemap</h4>
            <ul className="space-y-4 text-gray-400">
              <li><Link to="/events" className="hover:text-white hover:pl-2 transition-all block">Events</Link></li>
              <li><Link to="/about" className="hover:text-white hover:pl-2 transition-all block">Our Story</Link></li>
              <li><Link to="/media" className="hover:text-white hover:pl-2 transition-all block">Media Gallery</Link></li>
              <li><Link to="/community" className="hover:text-white hover:pl-2 transition-all block">Community</Link></li>
              <li><Link to="/contact" className="hover:text-white hover:pl-2 transition-all block">Contact</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading font-bold text-lg mb-6 text-white">Inquiries</h4>
            <ul className="space-y-4 text-gray-400">
              <li className="flex items-center justify-between border-b border-white/10 pb-2 group cursor-pointer">
                <span>General Info</span> <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </li>
              <li className="flex items-center justify-between border-b border-white/10 pb-2 group cursor-pointer">
                <span>Partnerships</span> <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </li>
              <li className="flex items-center justify-between border-b border-white/10 pb-2 group cursor-pointer">
                <span>Press</span> <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </li>
            </ul>
          </div>
          
          {/* Legal */}
           <div>
            <h4 className="font-heading font-bold text-lg mb-6 text-white">Legal</h4>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li><a href="#" className="hover:underline">Privacy Policy</a></li>
              <li><a href="#" className="hover:underline">Terms of Service</a></li>
              <li><a href="#" className="hover:underline">Code of Conduct</a></li>
            </ul>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
          <p>&copy; 2025 Dos Leches.</p>
          <p className="mt-2 md:mt-0">Designed with ❤️ for the culture.</p>
        </div>
      </div>
    </footer>
  );
};