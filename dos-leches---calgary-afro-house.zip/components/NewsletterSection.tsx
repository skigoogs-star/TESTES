import React from 'react';
import { Send, Instagram, Music, Video } from 'lucide-react';
import { Reveal } from './ui/Reveal';

export const NewsletterSection = () => {
  return (
    <section className="py-20 bg-deep-terracotta text-white">
      <div className="container mx-auto px-6 max-w-4xl text-center">
        <Reveal>
          <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">Join the Sunset Tribe</h2>
          <p className="text-lg md:text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Be the first to know about new events, artist announcements, and exclusive presales. 
            Plus, get <span className="font-bold text-golden-yellow">$5 off your next ticket</span> when you sign up.
          </p>
          
          <form className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto mb-8" onSubmit={(e) => e.preventDefault()}>
            <input 
              type="email" 
              placeholder="Your email address" 
              className="px-6 py-3 rounded-lg text-charcoal focus:outline-none focus:ring-2 focus:ring-sunset-amber flex-grow"
              required
            />
            <button 
              type="submit" 
              className="bg-sunset-amber hover:bg-coral text-white font-heading font-bold px-8 py-3 rounded-lg transition-colors shadow-lg flex items-center justify-center gap-2"
            >
              Let's Go <Send size={18} />
            </button>
          </form>
          
          <p className="text-xs opacity-70 mb-8">We respect your inbox. Unsubscribe anytime.</p>
          
          <div className="flex justify-center gap-6">
             <a href="#" className="hover:text-golden-yellow transition-colors bg-white/10 p-3 rounded-full"><Instagram size={24} /></a>
             <a href="#" className="hover:text-golden-yellow transition-colors bg-white/10 p-3 rounded-full"><Music size={24} /></a>
             <a href="#" className="hover:text-golden-yellow transition-colors bg-white/10 p-3 rounded-full"><Video size={24} /></a>
          </div>
        </Reveal>
      </div>
    </section>
  );
};