import React from 'react';

interface MarqueeProps {
  children: React.ReactNode;
  direction?: 'left' | 'right';
  className?: string;
}

export const Marquee: React.FC<MarqueeProps> = ({ children, direction = 'left', className = '' }) => {
  return (
    <div className={`overflow-hidden flex whitespace-nowrap ${className}`}>
      <div className={`flex animate-${direction === 'left' ? 'marquee' : 'marquee-reverse'}`}>
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex-shrink-0 px-4">
            {children}
          </div>
        ))}
      </div>
    </div>
  );
};