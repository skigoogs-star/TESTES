import React from 'react';
import { Link } from 'react-router-dom';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  to?: string;
  onClick?: () => void;
  className?: string;
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  to, 
  onClick, 
  className = '',
  type = "button",
  disabled = false
}) => {
  const baseStyles = "inline-flex items-center justify-center px-8 py-3 rounded-lg font-heading font-bold text-sm tracking-wide transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    primary: "bg-sunset-amber text-white hover:bg-deep-terracotta hover:scale-105 shadow-lg shadow-sunset-amber/20 focus:ring-sunset-amber",
    secondary: "bg-white text-charcoal hover:bg-warm-sand shadow-md focus:ring-charcoal",
    outline: "bg-transparent border-2 border-white text-white hover:bg-white hover:text-charcoal focus:ring-white",
    ghost: "bg-transparent text-charcoal hover:bg-gray-100 focus:ring-charcoal",
  };

  const classes = `${baseStyles} ${variants[variant]} ${className}`;

  if (to) {
    return (
      <Link to={to} className={classes}>
        {children}
      </Link>
    );
  }

  return (
    <button type={type} onClick={onClick} className={classes} disabled={disabled}>
      {children}
    </button>
  );
};