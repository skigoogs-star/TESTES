import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Ticket } from 'lucide-react';
import { NAV_LINKS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';

export const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <>
      {/* Floating Desktop Nav */}
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="fixed top-6 left-0 right-0 z-50 flex justify-center pointer-events-none px-6"
      >
        <div className={`
          pointer-events-auto flex items-center gap-2 p-2 rounded-full 
          transition-all duration-300 ease-out border border-charcoal/5
          ${scrolled || isOpen ? 'bg-white/80 backdrop-blur-xl shadow-xl shadow-black/5' : 'bg-white/90 backdrop-blur-md shadow-lg'}
        `}>
          
          {/* Logo */}
          <Link to="/" className="w-10 h-10 rounded-full bg-charcoal flex items-center justify-center text-white font-heading font-bold text-sm hover:scale-105 transition-transform">
            DL
          </Link>

          {/* Desktop Links */}
          <nav className="hidden md:flex items-center gap-1 px-2">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`
                  px-4 py-2 rounded-full text-sm font-bold uppercase tracking-wide transition-all
                  ${location.pathname === link.path 
                    ? 'bg-warm-sand text-charcoal' 
                    : 'text-charcoal/70 hover:text-charcoal hover:bg-gray-100'}
                `}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* CTA */}
          <a 
            href="#tickets"
            className="hidden md:flex items-center gap-2 bg-sunset-amber text-white px-5 py-2.5 rounded-full font-heading font-bold text-sm uppercase hover:bg-deep-terracotta transition-colors"
          >
            Tickets
          </a>

          {/* Mobile Toggle */}
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center rounded-full bg-gray-100 text-charcoal hover:bg-gray-200 transition-colors"
          >
            {isOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </motion.header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, clipPath: "circle(0% at 100% 0%)" }}
            animate={{ opacity: 1, clipPath: "circle(150% at 100% 0%)" }}
            exit={{ opacity: 0, clipPath: "circle(0% at 100% 0%)" }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 bg-charcoal z-40 flex flex-col justify-center items-center"
          >
            <div className="flex flex-col items-center gap-6">
              {NAV_LINKS.map((link, i) => (
                <motion.div
                  key={link.name}
                  initial={{ y: 40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1 + (i * 0.1) }}
                >
                  <Link
                    to={link.path}
                    className="font-heading font-black text-5xl text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400 hover:to-sunset-amber transition-all"
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
              <motion.div
                initial={{ y: 40, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-8"
              >
                  <a 
                      href="#tickets"
                      className="bg-sunset-amber text-white px-8 py-4 rounded-full font-heading font-bold text-xl flex justify-center items-center gap-2"
                  >
                      <Ticket size={24} />
                      Get Tickets
                  </a>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};