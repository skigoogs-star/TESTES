export interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  description: string;
  price: string;
  image: string;
  isUpcoming: boolean;
  artist: string;
}

export interface Testimonial {
  id: number;
  quote: string;
  name: string;
  role?: string;
}

export interface TeamMember {
  id: number;
  name: string;
  role: string;
  bio: string;
  image: string;
}

export interface BlogPost {
  id: number;
  title: string;
  category: string;
  excerpt: string;
  author: string;
  date: string;
  image: string;
}

export interface Artist {
  id: number;
  name: string;
  origin: string;
  genre: string;
  image: string;
}